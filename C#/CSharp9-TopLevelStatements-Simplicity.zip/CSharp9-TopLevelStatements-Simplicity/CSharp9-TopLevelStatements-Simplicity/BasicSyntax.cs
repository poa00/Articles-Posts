﻿namespace CSharp9_TopLevelStatements_Simplicity;
public static class BasicSyntax
{
    public static void SimpleExample()
    {
        Console.WriteLine("Hello, C# 9 Top-Level Statements!");
    }
}
