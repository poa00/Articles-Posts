﻿namespace CSharp9_TopLevelStatements_Simplicity.CodeOrganisation
{
    // Define a class for a more organized structure
    public class Calculator
    {
        public int Add(int a, int b) => a + b;
    }

}
