﻿namespace CSharp9_TopLevelStatements_Simplicity.CodeOrganisation
{
    public static class Utilize
    {
        // Utilise the class in the traditional structure
        public static int CalculateResult()
        {
            var calculator = new Calculator();
            return calculator.Add(10, 20);
        }
    }
}
