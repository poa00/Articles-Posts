﻿namespace CSharp9_TopLevelStatements_Simplicity;
public static class UtilisingVariables
{
    public static void ExampleCode()
    {
        // C# 9 top-level statement with variables
        string greeting = "Hello";
        string name = "Ziggy";

        Console.WriteLine($"{greeting}, {name}!");

    }
}
